import { useState, useEffect, useCallback } from 'react'
import {
  isNative, createChannel, requestNotifPermission,
  scheduleBillNotifs, cancelBillNotifs, initPushNotifications,
} from './notifications.js'

// ── Palette ──────────────────────────────────────────────────────────────
const C = {
  bg:'#F0EEFF', surface:'#FFFFFF', primary:'#6C5CE7',
  primaryLight:'#A29BFE', primaryDark:'#5A4BD1', teal:'#00CEC9',
  text:'#2D3436', textMid:'#636E72', textDim:'#B2BEC3',
  late:'#E17055', lateBg:'#FFF0ED', soon:'#F0A500', soonBg:'#FFFAED',
  ok:'#00B894', okBg:'#EDFFF9', paid:'#00CEC9', paidBg:'#E6FFFE', white:'#FFFFFF',
}
const CAT_COLORS = {
  renda:'#6C5CE7', energia:'#FDCB6E', agua:'#74B9FF', gas:'#FF7675',
  internet:'#00CEC9', telemovel:'#A29BFE', seguro:'#55EFC4',
  sub:'#FD79A8', saude:'#E17055', outro:'#B2BEC3',
}
const CATS = [
  {id:'renda',l:'Renda',icon:'home'},{id:'energia',l:'Energia',icon:'bolt'},
  {id:'agua',l:'Água',icon:'water_drop'},{id:'gas',l:'Gás',icon:'local_fire_department'},
  {id:'internet',l:'Internet',icon:'wifi'},{id:'telemovel',l:'Telemóvel',icon:'smartphone'},
  {id:'seguro',l:'Seguro',icon:'shield'},{id:'sub',l:'Subscrição',icon:'autorenew'},
  {id:'saude',l:'Saúde',icon:'health_and_safety'},{id:'outro',l:'Outro',icon:'receipt_long'},
]
const MONTHS_FULL = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro']
const MONTHS_SHORT = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
const SAMPLE = [
  {id:'s1',name:'Renda',amount:750,dueDay:1,dueMonth:null,freq:'monthly',cat:'renda',notes:'',lastPaid:null},
  {id:'s2',name:'EDP Electricidade',amount:68,dueDay:20,freq:'monthly',cat:'energia',notes:'',lastPaid:null},
  {id:'s3',name:'NOS Internet',amount:38,dueDay:8,freq:'monthly',cat:'internet',notes:'',lastPaid:null},
]
const DEFAULT_NOTIF = { enabled: false, daysBefore: [1, 7], hour: 9, backendUrl: '' }

// ── Logic ─────────────────────────────────────────────────────────────────
function today0() { const t = new Date(); t.setHours(0,0,0,0); return t }
function cycleDue(b) {
  const t = today0()
  if (b.freq === 'monthly') return new Date(t.getFullYear(), t.getMonth(), b.dueDay)
  return new Date(t.getFullYear(), (b.dueMonth||1)-1, b.dueDay)
}
export function nextDue(b) {
  const t = today0(); const cd = cycleDue(b)
  if (b.lastPaid) {
    const lp = new Date(b.lastPaid); lp.setHours(0,0,0,0)
    if (lp >= cd) {
      if (b.freq === 'monthly') return new Date(cd.getFullYear(), cd.getMonth()+1, b.dueDay)
      return new Date(cd.getFullYear()+1, (b.dueMonth||1)-1, b.dueDay)
    }
  }
  if (b.freq === 'yearly' && cd < t && !b.lastPaid)
    return new Date(cd.getFullYear()+1, (b.dueMonth||1)-1, b.dueDay)
  return cd
}
function daysUntil(b) { return Math.round((nextDue(b) - today0()) / 86400000) }
function statusOf(b) {
  const lp = b.lastPaid ? (() => { const d = new Date(b.lastPaid); d.setHours(0,0,0,0); return d })() : null
  if (lp && lp >= cycleDue(b)) return 'paid'
  const d = daysUntil(b)
  if (d < 0) return 'late'; if (d <= 7) return 'soon'; return 'ok'
}
const STATUS = {
  late:{ c:C.late, bg:C.lateBg, lbl:(d) => `${-d}d atraso` },
  soon:{ c:C.soon, bg:C.soonBg, lbl:(d) => d===0?'Hoje':d===1?'Amanhã':`${d} dias` },
  ok:  { c:C.ok,   bg:C.okBg,   lbl:(d) => `${d} dias` },
  paid:{ c:C.paid, bg:C.paidBg, lbl:()  => 'Pago' },
}
export function fmtEur(n) {
  return n.toLocaleString('pt-PT', { minimumFractionDigits:2, maximumFractionDigits:2 }) + ' €'
}
function getCat(id) { return CATS.find(c => c.id === id) || CATS[9] }
const EMPTY = { name:'', amount:'', dueDay:'1', dueMonth:'1', freq:'monthly', cat:'outro', notes:'' }

// ── Icon ──────────────────────────────────────────────────────────────────
function Icon({ n, size=20, color, fill=0, style={} }) {
  return (
    <span className="material-symbols-outlined" style={{
      fontSize:size, color:color||C.textMid, userSelect:'none',
      display:'inline-flex', alignItems:'center', lineHeight:1,
      fontVariationSettings:`'FILL' ${fill},'wght' 400,'GRAD' 0,'opsz' 24`,
      ...style,
    }}>{n}</span>
  )
}

// ── App ───────────────────────────────────────────────────────────────────
export default function App() {
  const [bills, setBills] = useState([])
  const [ready, setReady] = useState(false)
  const [sheet, setSheet] = useState(false)       // false | 'new' | bill
  const [form, setForm] = useState(EMPTY)
  const [delConf, setDelConf] = useState(false)
  const [toast, setToast] = useState('')
  const [tab, setTab] = useState('home')
  const [notifSheet, setNotifSheet] = useState(false)
  const [notifSettings, setNotifSettings] = useState(DEFAULT_NOTIF)
  const [notifPermission, setNotifPermission] = useState(false)
  const [fcmToken, setFcmToken] = useState('')

  // ── Fonts
  useEffect(() => {
    const urls = [
      'https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800&display=swap',
      'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=swap',
    ]
    urls.forEach(href => {
      const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = href
      document.head.appendChild(l)
    })
    document.body.style.cssText = 'margin:0;background:#F0EEFF;'
  }, [])

  // ── Load storage
  useEffect(() => {
    ;(async () => {
      try {
        const [rb, rn] = await Promise.all([
          window.Capacitor
            ? window.Capacitor.Plugins.CapacitorSQLite?.query?.()
            : null,
          null,
        ]).catch(() => [null, null])
        // Use local storage approach compatible with both web and native
        const billsRaw = localStorage.getItem('contas-bills-v4')
        const notifRaw = localStorage.getItem('contas-notif-v4')
        setBills(billsRaw ? JSON.parse(billsRaw) : SAMPLE)
        setNotifSettings(notifRaw ? JSON.parse(notifRaw) : DEFAULT_NOTIF)
      } catch {
        setBills(SAMPLE)
        setNotifSettings(DEFAULT_NOTIF)
      }
      setReady(true)
    })()
  }, [])

  // ── Persist
  useEffect(() => { if (!ready) return; localStorage.setItem('contas-bills-v4', JSON.stringify(bills)) }, [bills, ready])
  useEffect(() => { localStorage.setItem('contas-notif-v4', JSON.stringify(notifSettings)) }, [notifSettings])

  // ── Init notifications on mount
  useEffect(() => {
    if (!isNative) return
    ;(async () => {
      await createChannel()
      const granted = await requestNotifPermission()
      setNotifPermission(granted)
      if (notifSettings.enabled) {
        initPushNotifications(notifSettings.backendUrl, setFcmToken)
      }
    })()
  }, [])

  // ── Schedule all on settings change
  const rescheduleAll = useCallback(async (billsList, settings) => {
    if (!isNative || !settings.enabled) return
    for (const b of billsList) {
      await scheduleBillNotifs(b, settings, nextDue, fmtEur)
    }
  }, [])

  function flash(m) { setToast(m); setTimeout(() => setToast(''), 2200) }
  function openNew() { setForm({...EMPTY}); setDelConf(false); setSheet('new') }
  function openEdit(b) { setForm({...b, dueMonth: b.dueMonth||1}); setDelConf(false); setSheet(b) }
  function closeSheet() { setSheet(false); setDelConf(false) }

  function markPaid(id, e) {
    e.stopPropagation()
    const updated = bills.map(b => b.id === id ? {...b, lastPaid: new Date().toISOString().slice(0,10)} : b)
    setBills(updated)
    // Cancel upcoming notifs for this bill
    cancelBillNotifs(id)
    flash('Marcado como pago ✓')
  }
  function markUnpaid(id, e) {
    e.stopPropagation()
    const updated = bills.map(b => b.id === id ? {...b, lastPaid: null} : b)
    setBills(updated)
    const bill = updated.find(b => b.id === id)
    if (bill) scheduleBillNotifs(bill, notifSettings, nextDue, fmtEur)
  }

  async function save() {
    const name = form.name?.trim()
    const amount = parseFloat(form.amount)
    const dueDay = Math.min(28, Math.max(1, parseInt(form.dueDay)||1))
    if (!name || isNaN(amount) || amount <= 0) return
    const bill = {
      id: sheet === 'new' ? Date.now().toString() : form.id,
      name, amount, dueDay,
      dueMonth: form.freq === 'yearly' ? parseInt(form.dueMonth)||1 : null,
      freq: form.freq, cat: form.cat, notes: form.notes||'',
      lastPaid: sheet === 'new' ? null : form.lastPaid,
    }
    const updated = sheet === 'new'
      ? [...bills, bill]
      : bills.map(b => b.id === bill.id ? bill : b)
    setBills(updated)
    // Schedule notifications for this bill
    const scheduled = await scheduleBillNotifs(bill, notifSettings, nextDue, fmtEur)
    closeSheet()
    flash(scheduled ? `Guardado · ${scheduled} notificaç${scheduled===1?'ão':'ões'} agendadas` : 'Guardado ✓')
  }

  async function del() {
    await cancelBillNotifs(form.id)
    setBills(p => p.filter(b => b.id !== form.id))
    closeSheet(); flash('Eliminado')
  }

  async function saveNotifSettings(ns) {
    setNotifSettings(ns)
    if (ns.enabled && !notifPermission) {
      const granted = await requestNotifPermission()
      setNotifPermission(granted)
      if (!granted) { flash('Permissão de notificações negada'); return }
    }
    if (ns.enabled) {
      initPushNotifications(ns.backendUrl, setFcmToken)
      await rescheduleAll(bills, ns)
      flash('Notificações activadas ✓')
    } else {
      // Cancel all
      for (const b of bills) await cancelBillNotifs(b.id)
      flash('Notificações desactivadas')
    }
    setNotifSheet(false)
  }

  const all = [...bills].sort((a,b) => daysUntil(a)-daysUntil(b))
  const shown = tab==='paid' ? all.filter(b=>statusOf(b)==='paid')
              : tab==='all'  ? all
              : all.filter(b => statusOf(b)!=='paid')
  const totalM = bills.reduce((s,b) => s+(b.freq==='monthly'?b.amount:b.amount/12), 0)
  const lateN = bills.filter(b=>statusOf(b)==='late').length
  const soonN = bills.filter(b=>statusOf(b)==='soon').length

  const FF = "'Nunito', sans-serif"

  if (!ready) return <div style={{background:C.bg, minHeight:'100vh'}} />

  return (
    <div style={{background:C.bg, minHeight:'100vh', fontFamily:FF, maxWidth:480, margin:'0 auto', position:'relative', paddingBottom:80}}>

      {/* ── Hero ── */}
      <div style={{
        background:`linear-gradient(135deg, ${C.primary} 0%, ${C.primaryLight} 65%, ${C.teal} 100%)`,
        borderRadius:'0 0 32px 32px', padding:'52px 24px 28px',
        position:'relative', overflow:'hidden',
      }}>
        <div style={{position:'absolute',top:-40,right:-30,width:160,height:160,borderRadius:'50%',background:'rgba(255,255,255,0.08)'}}/>
        <div style={{position:'absolute',top:20,right:40,width:80,height:80,borderRadius:'50%',background:'rgba(255,255,255,0.06)'}}/>
        <div style={{position:'absolute',bottom:-20,left:-20,width:120,height:120,borderRadius:'50%',background:'rgba(255,255,255,0.05)'}}/>

        <div style={{position:'relative', zIndex:1, display:'flex', justifyContent:'space-between', alignItems:'flex-start'}}>
          <div>
            <div style={{fontSize:13,color:'rgba(255,255,255,0.75)',fontWeight:700,letterSpacing:'0.06em',marginBottom:4}}>TOTAL MENSAL</div>
            <div style={{fontSize:36,fontWeight:800,color:'#fff',letterSpacing:'-0.5px',marginBottom:16}}>{fmtEur(totalM)}</div>
            <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
              {lateN>0 && <HeroBadge icon="error" label={`${lateN} em atraso`} bg="rgba(255,118,96,0.25)"/>}
              {soonN>0 && <HeroBadge icon="schedule" label={`${soonN} esta semana`} bg="rgba(255,255,255,0.15)"/>}
              {lateN===0&&soonN===0&&bills.length>0 && <HeroBadge icon="check_circle" label="Tudo em dia" bg="rgba(85,239,196,0.25)"/>}
              <HeroBadge icon="receipt_long" label={`${bills.length} conta${bills.length!==1?'s':''}`} bg="rgba(255,255,255,0.12)"/>
            </div>
          </div>
          {/* Notification bell */}
          <button onClick={() => setNotifSheet(true)} style={{
            background: notifSettings.enabled ? 'rgba(255,255,255,0.2)' : 'rgba(255,255,255,0.1)',
            border: `1.5px solid ${notifSettings.enabled ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.2)'}`,
            borderRadius:14, width:44, height:44, cursor:'pointer',
            display:'flex', alignItems:'center', justifyContent:'center',
          }}>
            <Icon n={notifSettings.enabled ? 'notifications_active' : 'notifications'} size={22} color="rgba(255,255,255,0.9)" fill={notifSettings.enabled?1:0}/>
          </button>
        </div>
      </div>

      {/* ── Tabs ── */}
      <div style={{display:'flex',margin:'18px 20px 0',background:C.surface,borderRadius:16,padding:4,boxShadow:'0 2px 12px rgba(108,92,231,0.08)'}}>
        {[['home','Pendentes','pending'],['paid','Pagas','check_circle'],['all','Todas','list']].map(([id,l,icon])=>(
          <button key={id} onClick={()=>setTab(id)} style={{
            flex:1,padding:'10px 8px',border:'none',borderRadius:12,cursor:'pointer',
            background:tab===id?C.primary:'transparent',
            color:tab===id?C.white:C.textMid,
            fontFamily:FF,fontSize:12,fontWeight:700,
            display:'flex',alignItems:'center',justifyContent:'center',gap:5,
            transition:'all 0.15s',
          }}>
            <Icon n={icon} size={15} color={tab===id?C.white:C.textMid} fill={tab===id?1:0}/>
            {l}
          </button>
        ))}
      </div>

      {/* ── List ── */}
      <div style={{padding:'16px 20px 8px'}}>
        {shown.length===0 ? (
          <div style={{textAlign:'center',paddingTop:48,color:C.textDim}}>
            <Icon n="receipt_long" size={52} color={C.textDim}/>
            <div style={{fontSize:15,color:C.textMid,fontWeight:600,marginTop:12}}>
              {tab==='paid'?'Nenhuma paga':tab==='all'?'Sem contas':'Nenhuma pendente'}
            </div>
            {tab==='home'&&<div style={{fontSize:13,marginTop:6,color:C.textDim}}>Toca no + para adicionar</div>}
          </div>
        ) : shown.map(b => {
          const st = statusOf(b); const {c,bg,lbl} = STATUS[st]; const d = daysUntil(b)
          const cat = getCat(b.cat); const catColor = CAT_COLORS[b.cat]||C.primary
          const paid = st==='paid'
          return (
            <div key={b.id} onClick={()=>openEdit(b)} style={{
              background:C.surface, borderRadius:20,
              boxShadow:'0 2px 12px rgba(108,92,231,0.06), 0 1px 4px rgba(0,0,0,0.04)',
              padding:'14px 16px', marginBottom:10, cursor:'pointer',
              display:'flex', alignItems:'center', gap:14,
              opacity:paid?0.75:1,
            }}>
              <div style={{width:48,height:48,borderRadius:16,flexShrink:0,background:paid?C.paidBg:`${catColor}18`,display:'flex',alignItems:'center',justifyContent:'center'}}>
                <Icon n={cat.icon} size={24} color={paid?C.paid:catColor} fill={1}/>
              </div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:15,fontWeight:700,color:paid?C.textMid:C.text,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis',textDecoration:paid?'line-through':'none'}}>
                  {b.name}
                </div>
                <div style={{fontSize:12,color:C.textDim,marginTop:2,display:'flex',alignItems:'center',gap:4}}>
                  <Icon n="event" size={12} color={C.textDim}/>
                  {b.freq==='monthly'?`Dia ${b.dueDay} de cada mês`:`${b.dueDay} ${MONTHS_SHORT[(b.dueMonth||1)-1]} (anual)`}
                </div>
                {b.notes&&<div style={{fontSize:11,color:C.textDim,marginTop:2,opacity:.8}}>{b.notes}</div>}
              </div>
              <div style={{display:'flex',flexDirection:'column',alignItems:'flex-end',gap:6,flexShrink:0}}>
                <div style={{fontSize:15,fontWeight:800,color:paid?C.textMid:C.text}}>{fmtEur(b.amount)}</div>
                <div style={{fontSize:11,fontWeight:700,color:c,background:bg,borderRadius:99,padding:'3px 10px',whiteSpace:'nowrap'}}>{lbl(d)}</div>
                <button onClick={paid?e=>markUnpaid(b.id,e):e=>markPaid(b.id,e)} style={{
                  display:'flex',alignItems:'center',gap:4,
                  background:paid?C.paidBg:`${C.primary}12`,
                  border:'none',borderRadius:99,padding:'4px 10px',
                  cursor:'pointer',color:paid?C.paid:C.primary,
                  fontSize:11,fontWeight:700,fontFamily:FF,whiteSpace:'nowrap',
                }}>
                  <Icon n={paid?'check_circle':'radio_button_unchecked'} size={13} color={paid?C.paid:C.primary} fill={paid?1:0}/>
                  {paid?'Pago':'Pagar'}
                </button>
              </div>
            </div>
          )
        })}
      </div>

      {/* ── Bottom Nav ── */}
      <div style={{
        position:'fixed',bottom:0,left:'50%',transform:'translateX(-50%)',
        width:'100%',maxWidth:480,background:C.surface,
        borderTop:`1px solid ${C.bg}`,
        boxShadow:'0 -4px 20px rgba(108,92,231,0.08)',
        display:'flex',alignItems:'center',justifyContent:'space-around',
        padding:'8px 0 20px',zIndex:20,
      }}>
        <NavBtn icon="home" label="Início" active/>
        <div style={{marginBottom:24}}>
          <button onClick={openNew} style={{
            width:56,height:56,borderRadius:18,
            background:`linear-gradient(135deg,${C.primary},${C.primaryLight})`,
            border:'none',cursor:'pointer',
            boxShadow:`0 4px 16px ${C.primary}55`,
            display:'flex',alignItems:'center',justifyContent:'center',
          }}>
            <Icon n="add" size={28} color={C.white}/>
          </button>
        </div>
        <NavBtn icon="notifications" label="Alertas" active={false} onClick={()=>setNotifSheet(true)}/>
      </div>

      {/* ── Notification Settings Sheet ── */}
      {notifSheet && (
        <NotifSheet
          settings={notifSettings}
          permission={notifPermission}
          fcmToken={fcmToken}
          isNative={isNative}
          onSave={saveNotifSettings}
          onClose={()=>setNotifSheet(false)}
          FF={FF}
        />
      )}

      {/* ── Bill Sheet ── */}
      {sheet !== false && (
        <div onClick={e=>e.target===e.currentTarget&&closeSheet()} style={{
          position:'fixed',inset:0,zIndex:100,
          background:'rgba(45,52,54,0.5)',backdropFilter:'blur(4px)',
          display:'flex',alignItems:'flex-end',
        }}>
          <div style={{
            background:C.surface,width:'100%',maxWidth:480,margin:'0 auto',
            borderRadius:'28px 28px 0 0',
            boxShadow:'0 -8px 40px rgba(108,92,231,0.15)',
            padding:'0 22px 48px',maxHeight:'90vh',overflowY:'auto',
          }}>
            <div style={{display:'flex',justifyContent:'center',padding:'14px 0 4px'}}>
              <div style={{width:40,height:4,background:C.bg,borderRadius:2}}/>
            </div>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:22,marginTop:8}}>
              <div style={{fontSize:20,fontWeight:800,color:C.text}}>{sheet==='new'?'Nova Conta':'Editar Conta'}</div>
              <button onClick={closeSheet} style={{background:C.bg,border:'none',width:36,height:36,borderRadius:12,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
                <Icon n="close" size={20} color={C.textMid}/>
              </button>
            </div>

            <FLabel>Nome</FLabel>
            <FInput value={form.name} onChange={v=>setForm(p=>({...p,name:v}))} placeholder="Ex: Água EPAL"/>
            <FLabel>Categoria</FLabel>
            <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:8,marginBottom:20}}>
              {CATS.map(c=>{
                const sel=form.cat===c.id; const cc=CAT_COLORS[c.id]||C.primary
                return(
                  <div key={c.id} onClick={()=>setForm(p=>({...p,cat:c.id}))} style={{background:sel?`${cc}15`:C.bg,border:`2px solid ${sel?cc:'transparent'}`,borderRadius:14,padding:'10px 4px',cursor:'pointer',textAlign:'center',transition:'all 0.12s'}}>
                    <Icon n={c.icon} size={22} color={sel?cc:C.textDim} fill={sel?1:0}/>
                    <div style={{fontSize:9,color:sel?cc:C.textDim,marginTop:4,fontWeight:sel?700:400}}>{c.l}</div>
                  </div>
                )
              })}
            </div>
            <FLabel>Valor (€)</FLabel>
            <FInput value={form.amount} onChange={v=>setForm(p=>({...p,amount:v}))} type="number" placeholder="0,00"/>
            <FLabel>Periodicidade</FLabel>
            <div style={{display:'flex',gap:10,marginBottom:20}}>
              {[['monthly','Mensal','event_repeat'],['yearly','Anual','calendar_today']].map(([v,l,icon])=>{
                const sel=form.freq===v
                return(
                  <div key={v} onClick={()=>setForm(p=>({...p,freq:v}))} style={{flex:1,display:'flex',alignItems:'center',justifyContent:'center',gap:8,padding:'13px',borderRadius:14,background:sel?`${C.primary}12`:C.bg,border:`2px solid ${sel?C.primary:'transparent'}`,cursor:'pointer',color:sel?C.primary:C.textMid,fontSize:13,fontWeight:sel?700:500,transition:'all 0.12s'}}>
                    <Icon n={icon} size={18} color={sel?C.primary:C.textMid} fill={sel?1:0}/>
                    {l}
                  </div>
                )
              })}
            </div>
            <div style={{display:'flex',gap:12,marginBottom:20}}>
              {form.freq==='yearly'&&(
                <div style={{flex:2}}>
                  <FLabel>Mês</FLabel>
                  <select value={form.dueMonth} onChange={e=>setForm(p=>({...p,dueMonth:e.target.value}))} style={{...fInpStyle,marginBottom:0,appearance:'none'}}>
                    {MONTHS_FULL.map((m,i)=><option key={i} value={i+1}>{m}</option>)}
                  </select>
                </div>
              )}
              <div style={{flex:1}}>
                <FLabel>Dia (1–28)</FLabel>
                <input type="number" min="1" max="28" value={form.dueDay} onChange={e=>setForm(p=>({...p,dueDay:e.target.value}))} style={{...fInpStyle,marginBottom:0}}/>
              </div>
            </div>
            <FLabel>Notas</FLabel>
            <FInput value={form.notes} onChange={v=>setForm(p=>({...p,notes:v}))} placeholder="Opcional"/>

            <button onClick={save} style={{width:'100%',padding:'16px',background:`linear-gradient(135deg,${C.primary},${C.primaryLight})`,color:C.white,fontFamily:FF,fontSize:15,fontWeight:800,letterSpacing:'0.04em',border:'none',borderRadius:16,cursor:'pointer',boxShadow:`0 4px 20px ${C.primary}40`,display:'flex',alignItems:'center',justifyContent:'center',gap:8}}>
              <Icon n="check" size={20} color={C.white}/>
              Guardar
            </button>

            {sheet!=='new'&&(delConf?(
              <div style={{marginTop:14}}>
                <div style={{fontSize:13,color:C.textMid,textAlign:'center',marginBottom:12}}>Eliminar <strong>"{form.name}"</strong>?</div>
                <div style={{display:'flex',gap:10}}>
                  <button onClick={del} style={{flex:1,padding:'13px',borderRadius:14,background:C.lateBg,color:C.late,border:'none',cursor:'pointer',fontFamily:FF,fontSize:13,fontWeight:700}}>Eliminar</button>
                  <button onClick={()=>setDelConf(false)} style={{flex:1,padding:'13px',borderRadius:14,background:C.bg,color:C.textMid,border:'none',cursor:'pointer',fontFamily:FF,fontSize:13,fontWeight:600}}>Cancelar</button>
                </div>
              </div>
            ):(
              <button onClick={()=>setDelConf(true)} style={{width:'100%',padding:'13px',marginTop:12,background:'none',color:C.late,border:`1.5px solid ${C.lateBg}`,borderRadius:14,cursor:'pointer',fontFamily:FF,fontSize:13,fontWeight:700,display:'flex',alignItems:'center',justifyContent:'center',gap:6}}>
                <Icon n="delete_outline" size={18} color={C.late}/>
                Eliminar conta
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ── Toast ── */}
      {toast&&(
        <div style={{position:'fixed',bottom:90,left:'50%',transform:'translateX(-50%)',background:C.text,color:C.white,padding:'12px 22px',borderRadius:16,fontSize:13,fontWeight:600,zIndex:200,pointerEvents:'none',whiteSpace:'nowrap',boxShadow:'0 4px 16px rgba(0,0,0,0.2)',display:'flex',alignItems:'center',gap:8}}>
          <Icon n="check_circle" size={16} color={C.teal} fill={1}/>
          {toast}
        </div>
      )}
    </div>
  )
}

// ── Notification Settings Sheet ───────────────────────────────────────────
function NotifSheet({ settings, permission, fcmToken, isNative, onSave, onClose, FF }) {
  const [s, setS] = useState({...settings})

  function toggleDay(d) {
    setS(p => ({
      ...p,
      daysBefore: p.daysBefore.includes(d)
        ? p.daysBefore.filter(x=>x!==d)
        : [...p.daysBefore, d].sort((a,b)=>b-a)
    }))
  }

  const DAY_OPTS = [
    {d:0, label:'No próprio dia'},
    {d:1, label:'1 dia antes'},
    {d:3, label:'3 dias antes'},
    {d:7, label:'7 dias antes'},
  ]

  return (
    <div onClick={e=>e.target===e.currentTarget&&onClose()} style={{position:'fixed',inset:0,zIndex:110,background:'rgba(45,52,54,0.5)',backdropFilter:'blur(4px)',display:'flex',alignItems:'flex-end'}}>
      <div style={{background:'#FFFFFF',width:'100%',maxWidth:480,margin:'0 auto',borderRadius:'28px 28px 0 0',boxShadow:'0 -8px 40px rgba(108,92,231,0.15)',padding:'0 22px 48px',maxHeight:'80vh',overflowY:'auto'}}>
        <div style={{display:'flex',justifyContent:'center',padding:'14px 0 4px'}}>
          <div style={{width:40,height:4,background:'#F0EEFF',borderRadius:2}}/>
        </div>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:24,marginTop:8}}>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            <div style={{width:40,height:40,borderRadius:12,background:`${C.primary}12`,display:'flex',alignItems:'center',justifyContent:'center'}}>
              <Icon n="notifications" size={22} color={C.primary} fill={1}/>
            </div>
            <div style={{fontSize:20,fontWeight:800,color:C.text}}>Notificações</div>
          </div>
          <button onClick={onClose} style={{background:'#F0EEFF',border:'none',width:36,height:36,borderRadius:12,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center'}}>
            <Icon n="close" size={20} color={C.textMid}/>
          </button>
        </div>

        {!isNative && (
          <div style={{background:'#FFF3E0',border:'1px solid #FDCB6E',borderRadius:14,padding:'12px 16px',marginBottom:20,display:'flex',gap:10,alignItems:'flex-start'}}>
            <Icon n="info" size={18} color={C.soon} fill={1} style={{marginTop:1,flexShrink:0}}/>
            <div style={{fontSize:13,color:'#5D4037',lineHeight:1.5}}>
              As notificações nativas só funcionam na app Android instalada. No browser é apenas uma pré-visualização.
            </div>
          </div>
        )}

        {/* Toggle */}
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',background:'#F0EEFF',borderRadius:16,padding:'16px',marginBottom:20}}>
          <div>
            <div style={{fontSize:15,fontWeight:700,color:C.text}}>Activar notificações</div>
            <div style={{fontSize:12,color:C.textMid,marginTop:2}}>Lembretes automáticos de pagamento</div>
          </div>
          <div onClick={()=>setS(p=>({...p,enabled:!p.enabled}))} style={{
            width:50,height:28,borderRadius:14,
            background:s.enabled?C.primary:'#B2BEC3',
            position:'relative',cursor:'pointer',transition:'background 0.2s',
          }}>
            <div style={{position:'absolute',top:3,left:s.enabled?22:3,width:22,height:22,borderRadius:11,background:'white',transition:'left 0.2s',boxShadow:'0 1px 4px rgba(0,0,0,0.2)'}}/>
          </div>
        </div>

        {s.enabled && (<>
          {/* When to notify */}
          <FLabel>Quando notificar</FLabel>
          <div style={{display:'flex',flexDirection:'column',gap:8,marginBottom:20}}>
            {DAY_OPTS.map(({d,label})=>{
              const sel = s.daysBefore.includes(d)
              return(
                <div key={d} onClick={()=>toggleDay(d)} style={{display:'flex',alignItems:'center',justifyContent:'space-between',background:sel?`${C.primary}10`:'#F0EEFF',border:`1.5px solid ${sel?C.primary:'transparent'}`,borderRadius:14,padding:'13px 16px',cursor:'pointer',transition:'all 0.12s'}}>
                  <div style={{display:'flex',alignItems:'center',gap:10}}>
                    <Icon n={sel?'check_box':'check_box_outline_blank'} size={20} color={sel?C.primary:C.textDim} fill={sel?1:0}/>
                    <span style={{fontSize:14,fontWeight:sel?700:500,color:sel?C.primary:C.textMid}}>{label}</span>
                  </div>
                </div>
              )
            })}
          </div>

          {/* Time */}
          <FLabel>Hora da notificação</FLabel>
          <div style={{display:'flex',gap:8,marginBottom:20}}>
            {[7,8,9,10,12,18].map(h=>{
              const sel=s.hour===h
              return(
                <div key={h} onClick={()=>setS(p=>({...p,hour:h}))} style={{flex:1,textAlign:'center',padding:'11px 6px',borderRadius:14,background:sel?`${C.primary}12`:'#F0EEFF',border:`1.5px solid ${sel?C.primary:'transparent'}`,cursor:'pointer',color:sel?C.primary:C.textMid,fontSize:13,fontWeight:sel?700:500}}>
                  {h}:00
                </div>
              )
            })}
          </div>

          {/* Backend URL */}
          <FLabel>URL do backend (push remoto)</FLabel>
          <input
            value={s.backendUrl}
            onChange={e=>setS(p=>({...p,backendUrl:e.target.value}))}
            placeholder="https://o-teu-backend.railway.app"
            style={{...fInpStyle}}
          />
          <div style={{fontSize:11,color:C.textDim,marginTop:-12,marginBottom:16,lineHeight:1.5}}>
            O token FCM é enviado para <code style={{background:'#F0EEFF',padding:'1px 4px',borderRadius:4}}>/api/register-device</code> no teu backend.
          </div>

          {/* FCM Token display */}
          {fcmToken&&(
            <div style={{background:'#F0EEFF',borderRadius:12,padding:'10px 14px',marginBottom:16}}>
              <div style={{fontSize:10,color:C.textMid,fontWeight:700,marginBottom:4}}>TOKEN FCM (copia para testar)</div>
              <div style={{fontSize:10,color:C.textDim,wordBreak:'break-all',lineHeight:1.6,fontFamily:'monospace'}}>{fcmToken}</div>
            </div>
          )}
        </>)}

        <button onClick={()=>onSave(s)} style={{width:'100%',padding:'16px',background:`linear-gradient(135deg,${C.primary},${C.primaryLight})`,color:'white',fontFamily:FF,fontSize:15,fontWeight:800,letterSpacing:'0.04em',border:'none',borderRadius:16,cursor:'pointer',boxShadow:`0 4px 20px ${C.primary}40`,display:'flex',alignItems:'center',justifyContent:'center',gap:8}}>
          <Icon n="save" size={20} color="white"/>
          Guardar configuração
        </button>
      </div>
    </div>
  )
}

// ── Shared ────────────────────────────────────────────────────────────────
const fInpStyle = {
  width:'100%', boxSizing:'border-box', background:'#F0EEFF',
  border:'2px solid transparent', borderRadius:14, padding:'13px 16px',
  color:'#2D3436', fontSize:14, fontFamily:"'Nunito',sans-serif",
  outline:'none', marginBottom:16, fontWeight:500,
}
function FInput({value,onChange,placeholder,type='text'}) {
  return <input type={type} value={value} placeholder={placeholder} onChange={e=>onChange(e.target.value)} style={fInpStyle}/>
}
function FLabel({children}) {
  return <div style={{fontSize:12,fontWeight:700,color:'#636E72',marginBottom:8,letterSpacing:'0.04em'}}>{children}</div>
}
function HeroBadge({icon,label,bg}) {
  return(
    <div style={{display:'flex',alignItems:'center',gap:5,background:bg,borderRadius:99,padding:'5px 12px 5px 8px'}}>
      <Icon n={icon} size={13} color="rgba(255,255,255,0.9)" fill={1}/>
      <span style={{fontSize:12,color:'rgba(255,255,255,0.9)',fontWeight:700}}>{label}</span>
    </div>
  )
}
function NavBtn({icon,label,active,onClick}) {
  return(
    <div onClick={onClick} style={{display:'flex',flexDirection:'column',alignItems:'center',gap:3,opacity:active?1:0.5,cursor:'pointer',padding:'0 16px'}}>
      <Icon n={icon} size={22} color={active?C.primary:C.textMid} fill={active?1:0}/>
      <span style={{fontSize:10,fontWeight:700,color:active?C.primary:C.textMid}}>{label}</span>
    </div>
  )
}
